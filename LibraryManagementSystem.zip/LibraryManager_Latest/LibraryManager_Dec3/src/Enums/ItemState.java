package Enums;

public enum ItemState {
    AVAILABLE,
    UNAVAILABLE
}
