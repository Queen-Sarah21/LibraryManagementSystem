package Enums;

public enum UserState {
    ACTIVE,
    INACTIVE
}
