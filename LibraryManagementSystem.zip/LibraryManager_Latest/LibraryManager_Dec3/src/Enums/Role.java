package Enums;

public enum Role {
    LIBRARIAN,
    MANAGER
}
