package Enums;

public enum Language {
    FR,
    EN
}
