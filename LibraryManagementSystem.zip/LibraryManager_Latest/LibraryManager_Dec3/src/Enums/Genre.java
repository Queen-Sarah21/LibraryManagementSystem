package Enums;

public enum Genre {
    FrenchLiterature,
    EnglishLiterature
}
