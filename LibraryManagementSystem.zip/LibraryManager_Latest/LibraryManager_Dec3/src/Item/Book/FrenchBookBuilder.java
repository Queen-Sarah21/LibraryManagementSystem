package Item.Book;

import Enums.Genre;
import Enums.ItemState;
import Enums.Language;

public class FrenchBookBuilder implements IBookBuilder{
    Book book;
    public FrenchBookBuilder(){this.book = new Book();}
    public void setTitle(String title){book.setTitle(title);}
    public void setAuthor(String author){book.setAuthorName(author);}
    public void setPubDate(String pubDate){book.setPublicationDate(pubDate);}
    public void setGenre(){book.setGenre(Genre.FrenchLiterature);}
    public void setLang(){book.setLanguage(Language.FR);}
    public void setState(){book.setItemState(ItemState.AVAILABLE);}
    public Book getBook() {return book;}
    public void reset(){this.book = new Book();}
}
